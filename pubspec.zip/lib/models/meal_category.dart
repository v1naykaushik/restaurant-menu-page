class MealCategory {
  final int id;
  final String name;
  final String addressPath;
  MealCategory(
      {required this.id, required this.name, required this.addressPath});
}
